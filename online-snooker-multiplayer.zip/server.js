const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const rooms = new Map();
const W = 900, H = 480, R = 9;
const colors = {
  red:"#d92727", yellow:"#f4d03f", green:"#229954", brown:"#8e5b3a",
  blue:"#2471a3", pink:"#f5a6c8", black:"#202020", white:"#ffffff"
};
function initialBalls() {
  const b = [{id:"cue", type:"cue", x:225, y:240, vx:0, vy:0, color:colors.white, potted:false}];
  const reds = [];
  const startX = 595, startY = 240, gap = 20;
  let id = 0;
  for (let row=0; row<5; row++) for (let col=0; col<=row; col++) {
    reds.push({id:"r"+(id++),type:"red",x:startX+row*gap*.87,y:startY+(col-row/2)*gap,vx:0,vy:0,color:colors.red,potted:false});
  }
  b.push(...reds);
  const spots = [
    ["yellow",colors.yellow,300,240],["green",colors.green,300,160],
    ["brown",colors.brown,300,320],["blue",colors.blue,450,240],
    ["pink",colors.pink,570,240],["black",colors.black,750,240]
  ];
  for (const [type,color,x,y] of spots) b.push({id:type,type,x,y,vx:0,vy:0,color,potted:false});
  return b;
}
function makeRoom(code) {
  return {code, players:[], balls:initialBalls(), scores:[0,0], turn:0, status:"waiting", lastShot:null};
}
function cleanState(room) {
  return {code:room.code, players:room.players.map(p=>({name:p.name,slot:p.slot})),
    balls:room.balls, scores:room.scores, turn:room.turn, status:room.status,
    lastShot:room.lastShot};
}
function emitRoom(room) { io.to(room.code).emit("state", cleanState(room)); }
function allStopped(room) { return room.balls.every(b=>b.potted || (Math.abs(b.vx)<0.08 && Math.abs(b.vy)<0.08)); }
function simulate(room) {
  const balls = room.balls;
  let steps = 0;
  while (!allStopped(room) && steps++ < 900) {
    for (const b of balls) {
      if (b.potted) continue;
      b.x += b.vx; b.y += b.vy;
      if (b.x < 42+R) { b.x=42+R; b.vx=Math.abs(b.vx)*.88; }
      if (b.x > W-42-R) { b.x=W-42-R; b.vx=-Math.abs(b.vx)*.88; }
      if (b.y < 42+R) { b.y=42+R; b.vy=Math.abs(b.vy)*.88; }
      if (b.y > H-42-R) { b.y=H-42-R; b.vy=-Math.abs(b.vy)*.88; }
    }
    for (let i=0;i<balls.length;i++) for (let j=i+1;j<balls.length;j++) {
      const a=balls[i], b=balls[j]; if(a.potted||b.potted) continue;
      const dx=b.x-a.x, dy=b.y-a.y, d=Math.hypot(dx,dy);
      if(d>0 && d<2*R) {
        const nx=dx/d, ny=dy/d, overlap=2*R-d;
        a.x-=nx*overlap/2; a.y-=ny*overlap/2; b.x+=nx*overlap/2; b.y+=ny*overlap/2;
        const rel=(a.vx-b.vx)*nx+(a.vy-b.vy)*ny;
        if(rel>0) { const impulse=rel*.96; a.vx-=impulse*nx; a.vy-=impulse*ny; b.vx+=impulse*nx; b.vy+=impulse*ny; }
      }
    }
    for (const b of balls) {
      if(b.potted) continue;
      const pocket = [[42,42],[450,35],[858,42],[42,438],[450,445],[858,438]];
      for(const [px,py] of pocket) if(Math.hypot(b.x-px,b.y-py)<22) {
        b.potted=true; b.vx=0; b.vy=0;
        if(b.type==="red") room.scores[room.turn]+=1;
        else if(b.type!=="cue") room.scores[room.turn]+=({yellow:2,green:3,brown:4,blue:5,pink:6,black:7}[b.type]||0);
        if(b.type==="cue") { b.potted=false; b.x=225; b.y=240; }
        break;
      }
    }
    for(const b of balls) { b.vx*=.992; b.vy*=.992; if(Math.hypot(b.vx,b.vy)<.08){b.vx=0;b.vy=0;} }
  }
  for(const b of balls) { b.vx=0; b.vy=0; }
  room.turn = 1-room.turn;
  if(room.balls.filter(b=>b.type==="red"&&!b.potted).length===0) room.status="finished";
}
io.on("connection", socket => {
  socket.on("join", ({code,name}) => {
    code=String(code||"").toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6);
    name=String(name||"Player").trim().slice(0,18)||"Player";
    if(!code) return socket.emit("errorMsg","Enter a room code.");
    let room=rooms.get(code); if(!room){room=makeRoom(code);rooms.set(code,room);}
    if(room.players.length>=2) return socket.emit("errorMsg","That room is full. Try another room code.");
    if(room.players.some(p=>p.id===socket.id)) return;
    const slot=room.players.length;
    room.players.push({id:socket.id,name,slot});
    socket.join(code); socket.data.room=code; socket.data.slot=slot;
    if(room.players.length===2) room.status="playing";
    socket.emit("joined",{slot,code}); emitRoom(room);
  });
  socket.on("shoot", ({angle,power}) => {
    const room=rooms.get(socket.data.room); if(!room||room.status!=="playing") return;
    const player=room.players.find(p=>p.id===socket.id);
    if(!player||player.slot!==room.turn||!allStopped(room)) return;
    const cue=room.balls.find(b=>b.id==="cue");
    if(!cue||cue.potted) return;
    const p=Math.max(1,Math.min(14,Number(power)||1));
    const a=Number(angle)||0;
    cue.vx=Math.cos(a)*p; cue.vy=Math.sin(a)*p;
    room.lastShot={by:player.name};
    emitRoom(room);
    setTimeout(()=>{ if(rooms.get(room.code)!==room)return; simulate(room); emitRoom(room); },80);
  });
  socket.on("disconnect",()=>{
    const code=socket.data.room, room=rooms.get(code); if(!room)return;
    room.players=room.players.filter(p=>p.id!==socket.id);
    if(room.players.length===0) rooms.delete(code);
    else { room.status="waiting"; emitRoom(room); io.to(code).emit("notice","Your opponent disconnected."); }
  });
});
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Snooker server running on ${PORT}`));
