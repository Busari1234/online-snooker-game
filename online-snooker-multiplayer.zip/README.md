# Online Snooker (multiplayer starter)

A simple 1-vs-1, room-code snooker game. It uses Node.js, Express and Socket.IO.

## Run it on your computer
1. Install Node.js (version 18 or newer).
2. Unzip this project.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000` in your browser.

## Let friends play over the internet
Deploy this folder to a Node.js hosting service that supports persistent WebSocket connections (for example Render, Railway, or another Node host). Set the start command to `npm start`. Share the deployed public URL with your friends. One player creates a room code and the other enters the same code.

## Notes
- This is an early playable multiplayer prototype, not a tournament-grade snooker simulator.
- It includes 15 reds, the six colours, turn switching, basic collisions, pockets and simplified point scoring.
- For production play, add proper snooker foul rules, colour re-spotting, frame/ match rules, anti-cheat validation, reconnect handling and stronger physics.
- The server is authoritative for turns and shot simulation. Room state is held in memory, so rooms reset when the server restarts.
